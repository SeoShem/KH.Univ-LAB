SwitchDoc Labs
May 2016

Fixed Double Read Issue

improved to work with both SwitchDoc Labs AM2315 and Adafruit AM2315

Changed to one read model from two reads.  Delay 20ms between reads minimum

This is a library for the AM2315 Humidity + Temp sensor

Written by Limor Fried/Ladyada for Adafruit Industries.  
BSD license

and by

EasternStarGeek

Arduino Library Tutorial
http://learn.adafruit.com/adafruit-all-about-arduino-libraries-install-use
